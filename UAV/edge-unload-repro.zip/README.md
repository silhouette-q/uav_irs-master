# 层粒度卸载 —— 系统建模（单 GPU + 多 GPU，DRL 环境形式）

复现论文 **Efficient Layer-Granularity Unloading for LLMs in Edge Computing** (IEEE TMC 2026) 第四节的**系统模型**，并按组会要求扩展到多 GPU。

## 范围（严格按组会要求）

- ✅ **只做系统建模**：忠实复现论文的成本模型，并封装成 DRL 环境（状态/动作/奖励）。
- ✅ **多 GPU 系统建模已完成**（本次新增）：决策变量/状态/目标/约束的扩展，**同样只建模**。
- ❌ **不实现任何求解算法**：LUA、`ComputeStrategy`、ski-rental 对偶解一律不写；多 GPU 的层分配/卸载时刻也**不做优化求解**。
- ❌ **不实现 DRL agent、不训练**：环境留好接口，agent 以后再插。

> 建模量 $C_i, D_i, \bar i, B$ 属于"系统建模"（论文 A/B/C 节的定义），不是求解算法，所以实现了；其中 $B$（多 GPU 版为 $B_g$）只作为将来约束 DRL 动作空间的**数学钩子**暴露出来，本代码不基于它做在线决策。

## 文件

| 文件 | 作用 |
|---|---|
| `system_model.py` | 单 GPU 核心成本模型：层参数、$C_i/D_i/\bar i/B$、`cost(t_bar, tau)`（式 2a） |
| `system_model_multi_gpu.py` | **多 GPU 系统模型**：分配 $g_i$、异构 $(M,N)$ 参数、跨 GPU 成本、显存约束、迁移开销、$B_g$ 钩子 |
| `arrivals.py` | 请求到达过程 + 统计量 $q_{B^+},\mu_{B^-},\sigma_{B^-}$（式 5a-5c） |
| `env_single_gpu.py` | 单 GPU DRL 环境（Gym 风格 `reset`/`step`） |
| `env_multi_gpu.py` | **多 GPU DRL 环境**：动作 = M 位卸载掩码（每 GPU 独立、不可逆） |
| `baselines.py` | 平凡参考策略（全保留 / 立刻全卸 / 固定阈值 $B$）——**非 LUA** |
| `validate_table1.py` | 单 GPU 验证：复现 TABLE I，断言成本 = 100/140/185/225 |
| `validate_multi_gpu.py` | **多 GPU 验证**（7 项子测试，可单跑）：M=1 退化 == TABLE I、同构等价、max≤sum、异构/显存/迁移/环境自洽 |
| `run_tests.py` | 统一测试入口：`--single` / `--multi` / 缺省全跑 |
| `demo.py` | 用 TABLE III 实测参数跑基线对比 |

## 运行

```bash
pip install numpy
python run_tests.py           # 全部验证 (单 GPU + 多 GPU)
python run_tests.py --single  # 只跑单 GPU (TABLE I)
python run_tests.py --multi   # 只跑多 GPU
python run_tests.py --multi degenerate env   # 只跑多 GPU 的指定子项
python validate_multi_gpu.py --list          # 列出多 GPU 全部子测试
python demo.py                # TABLE III 参数下的成本对比
```

## 状态 / 动作 / 奖励（MDP 定义）

一个 **episode = 一个空闲期**：$t=0$ 模型空闲、全部层在显存（状态 $s_N$），下一个请求在 $\tau$ 时刻到达（采样，对 agent 隐藏），agent 决定何时卸载可卸层。

- **状态（观测）**：`[已空闲时间 t, 是否已卸载, i_bar, B, q_B+, μ_B-, σ_B-, 当前内存 C, 当前延迟 D]`
  - 其中 `i_bar`、`B` 是数学钩子，供将来约束动作空间。
- **动作**：
  - 离散逐 tick（默认，在线决策）：`{HOLD 保持, UNLOAD 卸载可卸层}`，卸载不可逆。
  - 单发连续（`mode="single"`）：直接给卸载时刻 `t_bar`。
- **奖励**：每 tick `-(当前内存 C · dt)`；请求到达时追加 `-η·D(到达时状态)`。
  - **回合累计奖励 = -总成本**，等于论文式(2a)取负。`validate_table1.py` 已断言环境奖励与 `cost()` 自洽。

## 公式 ↔ 代码映射

| 论文 | 代码 |
|---|---|
| $c_i, d_i$ | `SystemModel.c`, `.d` |
| $C_i=\sum_{i'\le i}c_{i'}$ | `SystemModel.C[i]` |
| $D_i=\sum_{i'>i}d_{i'}$ | `SystemModel.D[i]` |
| $\bar i=\min\{i\mid D_i\le D_{QoS}\}$ (1a) | `SystemModel.i_bar` |
| $B=\eta D_{\bar i}/(C_N-C_{\bar i})$ | `SystemModel.B`（数学钩子） |
| 目标 $\eta D_i S_i(\tau)+\int C_i S_i(t)dt$ (2a) | `SystemModel.cost()` / 环境累计奖励 |
| QoS $S_i=0,\ i\le\bar i-1$ (2c) | 可卸层限定为 $\bar i+1..N$ |
| $q_{B^+},\mu_{B^-},\sigma_{B^-}$ (5a-5c) | `arrivals.window_stats()` |

## ⚠ 一个已解决的疑点：$D_i$ 用 `>i` 而非论文正文的 `≥i`

论文 A 节正文写 $D_i=\sum_{i'\ge i}d_{i'}$，但：
1. 与状态定义矛盾——状态 $s_i$ 已经**保留了第 $i$ 层**，服务请求只需重载它之后（$i'>i$）的层；
2. 用 `≥i` 无法复现 TABLE I 的成本数字，用 `>i` 才能得到 100/140/185/225。

因此代码采用 $D_i=\sum_{i'>i}d_{i'}$（$D_N=0$）。这也是论文算法伪代码实际隐含的定义，判断为正文笔误。

## TABLE I 验证（已手算 + 代码双重核对）

5 层，每层 1GB/1s，$\eta=30$，QoS≤2s ⇒ $\bar i=3$（$D_3=2$），可卸层 {4,5}，$B=30$。

| $t_{bar}$ | $\tau$ | 内存成本 | 加载延迟 | 总成本 |
|---|---|---|---|---|
| 30 | 20 | 100 | 0 | **100**（请求先到，全保留） |
| 10 | 20 | 80 | 2 | **140** |
| 10 | 35 | 125 | 2 | **185** |
| 30 | 35 | 165 | 2 | **225** |

⇒ $\tau$ 小该保留（100<140），$\tau$ 大该早卸（185<225），**同一决策在不同 $\tau$ 下成本高低反转** = 两目标冲突。

## 多 GPU 系统模型（本次实现，仍只建模不写算法）

设 $M$ 个 GPU（$g=1..M$），模型仍有 $N$ 层。相对单 GPU 的四点扩展：

### 决策变量
- **分配** $g_i \in \{1..M\}$：第 $i$ 层放在哪个 GPU（一个空闲期内固定，构造模型时给定，**不优化**）。
- **卸载时刻** $t_i \in [0,\infty]$：每层何时从其 GPU 卸载；2-斜率简化下退化为每 GPU 一个阈值 $\bar t_g$。

### 状态
- 每个 GPU 各自的保留层集合、显存占用（互相独立）。
- **异构**：层参数用 $(M,N)$ 矩阵 $c_{g,i}, d_{g,i}$——同一层在不同 GPU 上的内存/加载延迟可不同；每层的有效参数 `c_eff[i] = c[assign[i], i]`。

### 目标（式 2a 的多 GPU 推广）
$$\text{total} = \eta \cdot \text{LoadingDelay} + \sum_g \text{MemoryCost}_g + \kappa \sum_{\text{被迁移层}} c_{g,i}$$
- 重载延迟的聚合两种模式：`delay_agg="sum"`（各 GPU 串行重载，保守）/ `"max"`（并行重载，取最慢 GPU）。
- 迁移开销 $\kappa \cdot c$（可选，$\kappa=0$ 忽略）：分配偏离参考分配的层计一次搬运成本。

### 约束
- **QoS**：$\bar i$ 的多 GPU 版——仍取前缀常驻结构，$\bar i=\min\{i \mid \text{Delay}(\text{重载层 } i{+}1..N) \le D_{QoS}\}$，其中延迟按 `delay_agg` 聚合。`sum` + $M{=}1$ 时与单 GPU 完全一致。
- **显存**：每 GPU 保留层内存和 $\le$ `mem_cap[g]`；常驻层放不下的分配在构造时直接报错。

### 公式 ↔ 代码映射（多 GPU 部分）

| 建模量 | 代码 |
|---|---|
| 分配 $g_i$ | `MultiGPUSystemModel.assign` |
| 异构参数 $c_{g,i}, d_{g,i}$ | `.c`, `.d`（$(M,N)$ 矩阵）；`homogeneous()` 构造同构情形 |
| 有效参数 $c_{g_i,i}$ | `.c_eff`, `.d_eff` |
| $\bar i$ 多 GPU 版 | `.i_bar`（`_compute_i_bar`，延迟按 `delay_agg` 聚合） |
| 每 GPU 临界点 $B_g$ | `.B_per_gpu`（数学钩子，$B_g = \eta \sum d / \sum c$ 对该 GPU 可卸层） |
| 总成本 | `.cost(t_bar_per_gpu, tau)`（2-斜率）/ `.cost_schedule(t_list, tau, ref_assign)`（逐层一般版） |
| 显存约束 | `.check_mem_cap()` / 构造时常驻层可行性检查 |

### 多 GPU 环境 MDP（`env_multi_gpu.py`）
- **episode** = 一个空闲期，与单 GPU 相同。
- **观测**：全局 6 维 `[t, i_bar, q_B+, μ_B-, σ_B-, 当前D]` + 每 GPU 4 维 `[是否已卸, B_g, 当前显存, 显存上限]`，共 `6+4M` 维。
- **动作**：$M$ 位掩码（向量或整数二进制），`action[g]=1` 表示 GPU $g$ 立刻卸其可卸层；每 GPU 独立、不可逆。
- **奖励**：每 tick `-(跨 GPU 总内存 · dt)`；到达时追加 `-η·Delay`。**回合累计奖励 = -cost**，已断言自洽。
- 层→GPU 分配是 episode 级决策变量，暂由模型构造时固定；将来可作为上层动作扩展。

### 多 GPU 验证（`validate_multi_gpu.py`，以 TABLE I 为 ground-truth）
1. **M=1 退化** == 单 GPU（$\bar i$/B/四成本全同）；
2. **同构等价**：同构 M-GPU + `sum` + 全体同时刻卸 == 单 GPU 成本（M=2/3 均验证）；
3. **max ≤ sum**：并行重载延迟不大于串行；且并行会**放宽 QoS**（例中 $\bar i$: 3→1，因为两 GPU 可同时重载）；
4. **异构生效**：加载快的 GPU 上 $\bar i$ 更小；
5. **显存约束**：常驻层放不下时构造报错；
6. **迁移开销**：$\kappa\sum c$ 正确计入；
7. **环境自洽**：回合奖励 == -cost。

> 更远方向（组会）：把毕设的扩散模型 DRL 迁移进来求解，并用 $\bar i$、$B_g$、传统在线算法的性能下界去**约束 DRL 的动作空间**，加速收敛、保住性能底线。
