"""
baselines.py
============
平凡参考策略 (⚠ 不是 LUA, 不是论文的求解算法)。

这些策略只用于:
  1) 跑通 DRL 环境, 确认 reset/step/reward 工作正常;
  2) 提供成本对照, 直观看到"两目标冲突"(不同 τ 下谁更省)。

论文真正的在线算法 (LUA / ComputeStrategy) 本周【不实现】。
"""

from __future__ import annotations

import numpy as np

from env_single_gpu import ACTION_HOLD, ACTION_UNLOAD, SingleGPUUnloadEnv


class ThresholdPolicy:
    """阈值策略: 空闲时间达到 t_bar 就卸载可卸层。

    - t_bar = +inf  -> 永不卸载 (全保留基线)
    - t_bar = 0     -> 立刻全卸 (省内存基线)
    - t_bar = B     -> 固定在 ski-rental 临界点卸载 (确定性 break-even)
    """

    def __init__(self, t_bar: float, name: str = "") -> None:
        self.t_bar = float(t_bar)
        self.name = name or f"threshold(t_bar={t_bar})"

    def action(self, env: SingleGPUUnloadEnv) -> int:
        return ACTION_UNLOAD if env.t >= self.t_bar else ACTION_HOLD


def make_baselines(model) -> list[ThresholdPolicy]:
    """构造三个参考基线。"""
    B = model.B if np.isfinite(model.B) else 0.0
    return [
        ThresholdPolicy(np.inf, "always_retain (全保留)"),
        ThresholdPolicy(0.0, "immediate_unload (立刻全卸)"),
        ThresholdPolicy(B, f"fixed_threshold_B (t_bar=B={B:.1f})"),
    ]


def run_episode(env: SingleGPUUnloadEnv, policy: ThresholdPolicy) -> dict:
    """用给定策略跑一个 episode, 返回结算信息 (含总成本)。"""
    env.reset()
    done = False
    info = {}
    total_reward = 0.0
    while not done:
        a = policy.action(env)
        _, r, done, trunc, info = env.step(a)
        total_reward += r
        if trunc:
            break
    return {
        "policy": policy.name,
        "tau": info.get("tau"),
        "t_bar": info.get("t_bar"),
        "total_cost": info.get("total_cost"),
        "mem_cost": info.get("mem_cost"),
        "loading_delay": info.get("loading_delay"),
        "qos_ok": info.get("qos_ok"),
        "total_reward": total_reward,
    }


if __name__ == "__main__":
    from arrivals import ArrivalProcess
    from system_model import SystemModel

    m = SystemModel(c=np.ones(5), d=np.ones(5), eta=30.0, d_qos=2.0)
    for tau in (20.0, 35.0):
        print(f"\n=== tau = {tau} ===")
        for pol in make_baselines(m):
            env = SingleGPUUnloadEnv(m, ArrivalProcess(mode="deterministic", value=tau), dt=1.0)
            res = run_episode(env, pol)
            print(f"  {pol.name:<34} total_cost={res['total_cost']:.0f}")
