"""
validate_table1.py
==================
正确性验证: 复现论文 TABLE I 的动机例子。

设置: 5 层, 每层 c_i=1(GB), d_i=1(s), eta=30, QoS<=2s。
预期 (手算已核对):
  i_bar = 3  (D_3 = 2 <= 2), 可卸载层 = {4, 5}
  B = 30
  成本:
    (t_bar=30, tau=20) -> 100   (请求先到, 全保留)
    (t_bar=10, tau=20) -> 140
    (t_bar=10, tau=35) -> 185
    (t_bar=30, tau=35) -> 225
  结论: tau 小该保留(100<140), tau 大该早卸(185<225) —— 两目标冲突的实证。

同时验证:
  - cost_schedule (一般版) 与 cost (2-斜率版) 结果一致
  - DRL 环境的回合累计奖励 == -cost (环境与成本模型自洽)
"""

from __future__ import annotations

import sys

import numpy as np

# Windows 控制台默认 GBK, 强制 UTF-8 输出避免中文乱码/emoji 报错
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from arrivals import ArrivalProcess
from env_single_gpu import ACTION_HOLD, ACTION_UNLOAD, SingleGPUUnloadEnv
from system_model import SystemModel


def build_table1_model() -> SystemModel:
    return SystemModel(c=np.ones(5), d=np.ones(5), eta=30.0, d_qos=2.0)


def main() -> None:
    m = build_table1_model()
    print(m.summary())
    print()

    # --- 1. 建模量 ---
    assert m.i_bar == 3, f"i_bar 应为 3, 实际 {m.i_bar}"
    assert m.droppable_layers == [4, 5], f"可卸层应为 [4,5], 实际 {m.droppable_layers}"
    assert abs(m.B - 30.0) < 1e-9, f"B 应为 30, 实际 {m.B}"
    print("[OK] i_bar=3, 可卸层=[4,5], B=30")

    # --- 2. 四个成本 ---
    expected = {(30, 20): 100, (10, 20): 140, (10, 35): 185, (30, 35): 225}
    for (t_bar, tau), exp in expected.items():
        got = m.cost(t_bar, tau)["total"]
        assert abs(got - exp) < 1e-9, f"cost(t_bar={t_bar}, tau={tau}) 应为 {exp}, 实际 {got}"
        print(f"[OK] cost(t_bar={t_bar:>2}, tau={tau:>2}) = {got:.0f}  (预期 {exp})")

    # --- 3. 冲突关系 ---
    assert m.cost(30, 20)["total"] < m.cost(10, 20)["total"], "tau=20 应保留更省"
    assert m.cost(10, 35)["total"] < m.cost(30, 35)["total"], "tau=35 应早卸更省"
    print("[OK] 冲突关系: tau 小->保留更省, tau 大->早卸更省")

    # --- 4. cost_schedule 与 cost 一致 ---
    for t_bar, tau in expected:
        # 逐层调度: 前 i_bar 层永驻(inf), 可卸层在 t_bar 卸
        t_list = [np.inf] * m.i_bar + [t_bar] * len(m.droppable_layers)
        a = m.cost(t_bar, tau)["total"]
        b = m.cost_schedule(t_list, tau)["total"]
        assert abs(a - b) < 1e-9, f"两种成本算法不一致: {a} vs {b}"
    print("[OK] cost_schedule (一般版) 与 cost (2-斜率版) 完全一致")

    # --- 5. 环境自洽: 回合累计奖励 == -cost ---
    for t_bar, tau in expected:
        env = SingleGPUUnloadEnv(
            m, ArrivalProcess(mode="deterministic", value=float(tau)), dt=1.0
        )
        env.reset()
        done = False
        total_r = 0.0
        info = {}
        while not done:
            a = ACTION_UNLOAD if env.t >= t_bar else ACTION_HOLD
            _, r, done, trunc, info = env.step(a)
            total_r += r
            if trunc:
                break
        cost = m.cost(t_bar, tau)["total"]
        assert abs(total_r - (-cost)) < 1e-6, (
            f"环境奖励({total_r}) != -cost({-cost})  t_bar={t_bar}, tau={tau}"
        )
    print("[OK] DRL 环境回合累计奖励 == -cost (环境与成本模型自洽)")

    print("\n全部验证通过 [PASS]")


if __name__ == "__main__":
    main()
