"""
demo.py
=======
用论文 TABLE III 的实测层参数建模, 跑三个基线策略, 直观展示两目标冲突。

TABLE III (实测, 单位: 延迟 ms / 内存 MB):
  embedding   : 380 ms / 1188 MB
  transformer : 125 ms /  386 MB   (每个 block, 约 0.32 ms/MB, 印证 d_i ≈ k·c_i)
  fc (输出头) : 380 ms / 1188 MB

⚠ 本 demo 只用【系统模型 + 平凡基线】, 不含 LUA/DRL 求解算法。
"""

from __future__ import annotations

import sys

import numpy as np

# Windows 控制台默认 GBK, 强制 UTF-8 输出避免中文乱码
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from arrivals import ArrivalProcess
from baselines import make_baselines, run_episode
from env_single_gpu import SingleGPUUnloadEnv
from system_model import SystemModel


def build_table3_model(n_transformer: int = 24, eta: float = 500.0,
                       d_qos: float = 1000.0) -> SystemModel:
    """embedding + n_transformer 个 transformer + fc。"""
    c = [1188.0] + [386.0] * n_transformer + [1188.0]   # 内存 MB
    d = [380.0] + [125.0] * n_transformer + [380.0]     # 延迟 ms
    return SystemModel(c=np.array(c), d=np.array(d), eta=eta, d_qos=d_qos)


def demo_conflict(model: SystemModel) -> None:
    print("=" * 68)
    print("演示 1: 固定到达时刻下, 不同基线的成本 (展示两目标冲突)")
    print("=" * 68)
    B = model.B
    for mult, tag in [(0.4, "请求来得早"), (1.0, "≈临界点 B"), (2.5, "请求来得晚")]:
        tau = mult * B
        print(f"\n-- tau = {tau:.0f} ms ({tag}, = {mult}·B) --")
        for pol in make_baselines(model):
            env = SingleGPUUnloadEnv(
                model, ArrivalProcess(mode="deterministic", value=tau), dt=max(B / 200, 1.0)
            )
            res = run_episode(env, pol)
            print(f"   {pol.name:<34} 总成本={res['total_cost']:>12.0f}  "
                  f"QoS={'OK' if res['qos_ok'] else 'X'}")


def demo_stochastic(model: SystemModel, n_episodes: int = 2000) -> None:
    print("\n" + "=" * 68)
    print(f"演示 2: 随机负载(指数到达, 均值=B)下 {n_episodes} 回合平均成本")
    print("=" * 68)
    B = model.B
    for pol in make_baselines(model):
        costs = []
        arr = ArrivalProcess(mode="exponential", mean=B, seed=2026)
        env = SingleGPUUnloadEnv(model, arr, dt=max(B / 100, 1.0))
        for _ in range(n_episodes):
            res = run_episode(env, pol)
            costs.append(res["total_cost"])
        costs = np.array(costs)
        print(f"   {pol.name:<34} 平均成本={costs.mean():>12.0f}  "
              f"(标准差={costs.std():.0f})")
    print("\n注: 没有哪个固定基线在所有 τ 下都最优 —— 这正是需要在线/学习型策略的原因。")


def main() -> None:
    model = build_table3_model()
    print(model.summary())
    print(f"\n总层数 N={model.N}, 可卸载层数={len(model.droppable_layers)} "
          f"(层 {model.droppable_layers[0]}..{model.droppable_layers[-1]})")
    print(f"d_i/c_i (前几层): {np.round(model.d[:4] / model.c[:4], 4)}  "
          f"(应接近常数, 印证 d_i≈k·c_i)\n")
    demo_conflict(model)
    demo_stochastic(model)


if __name__ == "__main__":
    main()
