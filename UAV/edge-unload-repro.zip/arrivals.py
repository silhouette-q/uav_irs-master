"""
arrivals.py
===========
请求到达过程 + 到达间隔统计量。

说明: 这属于【系统建模的输入部分】(刻画请求何时到达), 不是求解算法。
论文式(5a)-(5c) 用到三个统计量, 这里如实实现它们的经验估计:

  ∫_0^B q(τ) dτ + q_{B+} = 1        (5a)  -> q_{B+} = 长间隔(>B)出现的概率
  ∫_0^B τ  q(τ) dτ = μ_{B-}         (5b)  -> 短间隔的一阶矩
  ∫_0^B τ² q(τ) dτ = σ_{B-}         (5c)  -> 短间隔的二阶矩

其中 q(τ) 是请求到达间隔的概率密度, B 是 ski-rental 临界点。
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ArrivalProcess:
    """可配置的请求到达间隔采样器。

    mode:
      - "deterministic": 每次返回固定值 value, 或按 sequence 循环
      - "exponential"  : 指数分布, 均值 = mean
      - "empirical"    : 从给定 samples 中有放回抽样
    """

    mode: str = "exponential"
    mean: float = 10.0
    value: float = 10.0
    sequence: list[float] | None = None
    samples: list[float] | None = None
    seed: int = 0

    rng: np.random.Generator = field(init=False)
    _seq_idx: int = field(init=False, default=0)

    def __post_init__(self) -> None:
        self.rng = np.random.default_rng(self.seed)

    def sample(self) -> float:
        """采样下一个请求的到达间隔 τ (> 0)。"""
        if self.mode == "deterministic":
            if self.sequence:
                v = float(self.sequence[self._seq_idx % len(self.sequence)])
                self._seq_idx += 1
                return v
            return float(self.value)
        if self.mode == "exponential":
            return float(self.rng.exponential(self.mean))
        if self.mode == "empirical":
            if not self.samples:
                raise ValueError("empirical 模式需要提供 samples")
            return float(self.rng.choice(self.samples))
        raise ValueError(f"未知 mode: {self.mode}")

    def sample_many(self, n: int) -> np.ndarray:
        return np.array([self.sample() for _ in range(n)])


def window_stats(intervals, B: float) -> dict:
    """由一批到达间隔样本估计论文式(5a)-(5c)的统计量。

    参数
    ----
    intervals : 最近观测到的一批到达间隔 (滑动窗口内的样本)。
    B : ski-rental 临界点, 用于区分"短间隔(<=B)"与"长间隔(>B)"。

    返回
    ----
    q_B_plus : 长间隔概率 (>B 的比例)                 -> 式(5a)
    mu_B_minus : 短间隔一阶矩 = mean(τ·1{τ<=B})       -> 式(5b)
    sigma_B_minus : 短间隔二阶矩 = mean(τ²·1{τ<=B})   -> 式(5c)
    """
    x = np.asarray(list(intervals), dtype=float)
    if x.size == 0:
        return {"q_B_plus": 0.0, "mu_B_minus": 0.0, "sigma_B_minus": 0.0, "n": 0}

    is_long = x > B
    short = x[~is_long]

    q_B_plus = float(is_long.mean())
    # 一/二阶矩按对全体样本取期望的形式 (短间隔贡献, 长间隔贡献 0), 与积分 ∫_0^B 一致
    mu_B_minus = float(short.sum() / x.size)
    sigma_B_minus = float((short ** 2).sum() / x.size)

    return {
        "q_B_plus": q_B_plus,
        "mu_B_minus": mu_B_minus,
        "sigma_B_minus": sigma_B_minus,
        "n": int(x.size),
    }


class SlidingWindow:
    """维护最近 K 个到达间隔的滑动窗口 (论文 F 节动态负载用到)。"""

    def __init__(self, capacity: int = 50) -> None:
        self.capacity = capacity
        self._buf: list[float] = []

    def push(self, interval: float) -> None:
        self._buf.append(float(interval))
        if len(self._buf) > self.capacity:
            self._buf.pop(0)

    @property
    def intervals(self) -> list[float]:
        return list(self._buf)

    def stats(self, B: float) -> dict:
        return window_stats(self._buf, B)


if __name__ == "__main__":
    ap = ArrivalProcess(mode="exponential", mean=20.0, seed=42)
    xs = ap.sample_many(1000)
    print("样本均值:", round(float(xs.mean()), 2))
    print("统计量 (B=30):", window_stats(xs, B=30.0))
