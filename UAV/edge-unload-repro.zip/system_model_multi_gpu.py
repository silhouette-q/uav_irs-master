"""
system_model_multi_gpu.py
=========================
多 GPU「层粒度卸载」系统模型 —— 单 GPU 模型 (system_model.py) 的自然扩展。

⚠ 范围声明 (对齐组会要求): 本文件只做【系统建模】, 不含任何求解算法。
   不实现分配/卸载的优化求解 (那是将来 DRL / 在线算法的事);
   这里只定义 决策变量、状态、目标函数、约束, 并提供成本计算。

--------------------------------------------------------------------
建模扩展 (相对单 GPU, 对应 README "多 GPU 扩展设计")
--------------------------------------------------------------------
设 M 个 GPU (g = 1..M), 模型仍有 N 层 (i = 1..N)。

1. 决策变量:
   - 分配 g_i ∈ {1..M}: 第 i 层放在哪个 GPU 上 (一个空闲期内固定,
     由外部给定 —— 本文件不优化它)。
   - 卸载时刻 t_i ∈ [0, +inf]: 第 i 层何时从其 GPU 卸载 (inf = 永不卸)。
     2-斜率简化下退化为每个 GPU 一个阈值 t_bar_g。

2. 状态:
   - 每个 GPU 各自的保留层集合 / 显存占用 (互相独立);
   - 异构: 同一层在不同 GPU 上的内存 c_{g,i}、加载延迟 d_{g,i} 可不同,
     故层参数用 (M, N) 矩阵表示; 同构时各行相同。

3. 目标 (式 2a 的多 GPU 推广):
     total = eta * LoadingDelay(到达时各 GPU 状态) + sum_g MemoryCost_g
   其中
     MemoryCost_g = ∫_0^tau (GPU g 上保留层的内存和) dt
     LoadingDelay = 聚合_g ( GPU g 上已卸层的重载延迟和 )
       - delay_agg="sum": 各 GPU 串行重载 (保守上界)
       - delay_agg="max": 各 GPU 并行重载 (取最慢者, 更贴近实际)
   可选迁移开销: 若层的分配与"参考分配"不同, 计一次性迁移成本 κ·c_{g,i}
   (GPU 间搬运数据量正比于层大小)。

4. 约束:
   - QoS: 全体常驻层保证 重载延迟 <= D_QoS (由 i_bar 的多 GPU 版保证);
   - 显存: 每个 GPU 上保留层内存和 <= mem_cap[g] (随时检查, 越界即不可行)。

--------------------------------------------------------------------
QoS 与 i_bar 的多 GPU 版
--------------------------------------------------------------------
单 GPU 时 QoS 给出"前 i_bar 层永驻"。多 GPU 下层被分到不同 GPU,
嵌套结构不再自动成立, 但论文式(1a)的逻辑不变:

  常驻集合 R ⊆ I 满足 QoS  <=>  Delay(I 去掉 R) <= D_QoS

我们保持与单 GPU 一致的"前缀常驻"结构 (论文 A 节: 越靠前的层越先用到,
保留必须从第 1 层开始连续): 仍定义

  i_bar = min{ i | Delay(重载层 i+1..N) <= D_QoS }

其中重载延迟按 delay_agg 聚合各 GPU 上的份额。可卸载层仍为 i_bar+1..N。

每个 GPU g 有自己的 ski-rental 临界点钩子:
  B_g = eta * (GPU g 上可卸层的延迟和) / (GPU g 上可卸层的内存和)
(仅作数学钩子暴露, 供将来约束 DRL 动作空间; 本文件不用它做决策。)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass
class MultiGPUSystemModel:
    """多 GPU 层粒度卸载的系统模型 (纯建模, 无求解算法)。

    参数
    ----
    c : (M, N) 矩阵, c[g, i] = 第 i+1 层放在 GPU g+1 上的内存占用。
        同构时各行相同; 也接受长度 N 的向量 (自动广播为同构 M 行)。
    d : (M, N) 矩阵, 同上, 加载延迟。
    eta : 加载延迟权重 (论文 eta)。
    d_qos : QoS 约束, 加载延迟上限 D_QoS。
    assign : 长度 N, assign[i] = 第 i+1 层分配到的 GPU (0-based, 0..M-1)。
        决策变量之一, 由外部给定, 本模型不优化它。
    mem_cap : 长度 M, 各 GPU 显存上限; None = 不设上限。
    delay_agg : "sum" 串行重载 | "max" 并行重载。
    kappa : GPU 间迁移开销系数 (迁移成本 = kappa * 层内存); 0 = 忽略迁移。
    """

    c: np.ndarray
    d: np.ndarray
    eta: float
    d_qos: float
    assign: np.ndarray
    mem_cap: np.ndarray | None = None
    delay_agg: str = "sum"
    kappa: float = 0.0

    # 派生量
    M: int = field(init=False)
    N: int = field(init=False)
    c_eff: np.ndarray = field(init=False)   # c_eff[i] = c[assign[i], i], 长度 N
    d_eff: np.ndarray = field(init=False)   # d_eff[i] = d[assign[i], i]
    i_bar: int = field(init=False)
    B_per_gpu: np.ndarray = field(init=False)   # 每 GPU 的 ski-rental 钩子, 长度 M

    def __post_init__(self) -> None:
        self.c = np.atleast_2d(np.asarray(self.c, dtype=float))
        self.d = np.atleast_2d(np.asarray(self.d, dtype=float))
        if self.c.shape != self.d.shape:
            raise ValueError("c 和 d 形状必须一致 (M, N)")
        self.M, self.N = self.c.shape

        self.assign = np.asarray(self.assign, dtype=int)
        if self.assign.shape[0] != self.N:
            raise ValueError("assign 长度必须等于层数 N")
        if self.assign.min() < 0 or self.assign.max() >= self.M:
            raise ValueError("assign 取值必须在 0..M-1")

        if self.delay_agg not in ("sum", "max"):
            raise ValueError('delay_agg 只能是 "sum" 或 "max"')

        if self.mem_cap is not None:
            self.mem_cap = np.asarray(self.mem_cap, dtype=float)
            if self.mem_cap.shape[0] != self.M:
                raise ValueError("mem_cap 长度必须等于 GPU 数 M")

        # 每层在"它所分配的 GPU"上的有效参数 (异构关键点)
        idx = np.arange(self.N)
        self.c_eff = self.c[self.assign, idx]
        self.d_eff = self.d[self.assign, idx]

        self.i_bar = self._compute_i_bar()
        self.B_per_gpu = self._compute_B_per_gpu()

        # 常驻层 (1..i_bar) 必须能放下 —— 建模层面的可行性检查
        if self.mem_cap is not None:
            resident = np.zeros(self.M)
            for i in range(self.i_bar):
                resident[self.assign[i]] += self.c_eff[i]
            if np.any(resident > self.mem_cap + 1e-9):
                raise ValueError(
                    f"QoS 要求前 {self.i_bar} 层常驻, 但该分配下超出显存上限: "
                    f"resident={resident}, cap={self.mem_cap}"
                )

    # ---------- 派生建模量 ----------
    def _reload_delay(self, unloaded_mask: np.ndarray) -> float:
        """给定已卸载层掩码 (长度 N 的 bool), 按 delay_agg 聚合各 GPU 的重载延迟。

        每个 GPU 重载自己上面的已卸层; sum = 串行, max = 并行取最慢。
        """
        per_gpu = np.zeros(self.M)
        np.add.at(per_gpu, self.assign[unloaded_mask], self.d_eff[unloaded_mask])
        if self.delay_agg == "max":
            return float(per_gpu.max()) if self.M > 0 else 0.0
        return float(per_gpu.sum())

    def _compute_i_bar(self) -> int:
        """i_bar = min{ i | Delay(重载层 i+1..N) <= D_QoS } —— 式(1a)的多 GPU 版。

        保持单 GPU 的前缀常驻结构 (前 i 层保留, 后 N-i 层卸载),
        重载延迟按 delay_agg 聚合。delay_agg="sum" 且 M=1 时与单 GPU 完全一致。
        """
        for i in range(self.N + 1):
            mask = np.zeros(self.N, dtype=bool)
            mask[i:] = True                      # 第 i+1..N 层已卸载
            if self._reload_delay(mask) <= self.d_qos:
                return i
        raise ValueError("没有满足 QoS 的状态, 检查 d_qos 是否为负")

    def _compute_B_per_gpu(self) -> np.ndarray:
        """每个 GPU 的 ski-rental 临界点钩子 (仅暴露, 不用于决策)。

        B_g = eta * (g 上可卸层延迟和) / (g 上可卸层内存和);
        g 上没有可卸层时为 inf。M=1 时退化为单 GPU 的 B。
        """
        B = np.full(self.M, math.inf)
        droppable = np.zeros(self.N, dtype=bool)
        droppable[self.i_bar:] = True
        for g in range(self.M):
            mask = droppable & (self.assign == g)
            mem = float(self.c_eff[mask].sum())
            if mem > 0:
                B[g] = self.eta * float(self.d_eff[mask].sum()) / mem
        return B

    @property
    def droppable_layers(self) -> list[int]:
        """可卸载层的 1-based 编号列表: i_bar+1 .. N。"""
        return list(range(self.i_bar + 1, self.N + 1))

    def layers_on_gpu(self, g: int) -> list[int]:
        """GPU g (0-based) 上的层 (1-based 编号)。"""
        return [i + 1 for i in range(self.N) if self.assign[i] == g]

    # ---------- 状态查询 ----------
    def gpu_memory_usage(self, retained_mask: np.ndarray) -> np.ndarray:
        """给定保留层掩码, 返回各 GPU 当前显存占用 (长度 M)。"""
        usage = np.zeros(self.M)
        np.add.at(usage, self.assign[retained_mask], self.c_eff[retained_mask])
        return usage

    def check_mem_cap(self, retained_mask: np.ndarray) -> bool:
        """各 GPU 显存约束是否满足。"""
        if self.mem_cap is None:
            return True
        return bool(np.all(self.gpu_memory_usage(retained_mask) <= self.mem_cap + 1e-9))

    # ---------- 成本 (式 2a 的多 GPU 推广) ----------
    def cost_schedule(self, t_list, tau: float, ref_assign=None) -> dict:
        """一般版成本: 每层一个卸载时刻 t_list[j] (层 j+1, inf=永不卸)。

        memory_cost   = sum_i c_eff[i] * min(t_i, tau)      跨 GPU 总内存成本
        loading_delay = 聚合_g( sum_{i on g, t_i<=tau} d_eff[i] )
        migration     = kappa * sum_{assign != ref_assign} c_eff[i]   (可选)
        total         = eta * loading_delay + memory_cost + migration

        M=1、delay_agg="sum" 时与单 GPU SystemModel.cost_schedule 完全一致。
        """
        t_arr = np.asarray(t_list, dtype=float)
        if t_arr.shape[0] != self.N:
            raise ValueError("t_list 长度必须等于层数 N")

        retained_dur = np.minimum(t_arr, tau)
        memory_cost = float((self.c_eff * retained_dur).sum())

        unloaded = t_arr <= tau
        loading_delay = self._reload_delay(unloaded)

        migration_cost = 0.0
        if ref_assign is not None and self.kappa > 0:
            moved = np.asarray(ref_assign, dtype=int) != self.assign
            migration_cost = self.kappa * float(self.c_eff[moved].sum())

        total = self.eta * loading_delay + memory_cost + migration_cost
        return {
            "total": total,
            "memory_cost": memory_cost,
            "loading_delay": loading_delay,
            "migration_cost": migration_cost,
            "qos_ok": loading_delay <= self.d_qos,
            "per_gpu_mem_at_arrival": self.gpu_memory_usage(~unloaded).tolist(),
        }

    def cost(self, t_bar_per_gpu, tau: float) -> dict:
        """2-斜率版成本: 每个 GPU 一个卸载阈值 t_bar_g (长度 M)。

        GPU g 上的可卸层在 t_bar_g 同时卸载, 常驻层 (1..i_bar) 永不卸。
        这是论文 C 节"可卸层同时刻卸"结论按 GPU 的推广。
        """
        t_bar = np.asarray(t_bar_per_gpu, dtype=float)
        if t_bar.shape[0] != self.M:
            raise ValueError("t_bar_per_gpu 长度必须等于 GPU 数 M")

        t_list = np.full(self.N, np.inf)
        for i in range(self.i_bar, self.N):        # 可卸层
            t_list[i] = t_bar[self.assign[i]]
        return self.cost_schedule(t_list, tau)

    # ---------- 便捷打印 ----------
    def summary(self) -> str:
        lines = [
            f"MultiGPUSystemModel(M={self.M}, N={self.N}, eta={self.eta}, "
            f"D_QoS={self.d_qos}, delay_agg={self.delay_agg}, kappa={self.kappa})",
            f"  分配 assign (层->GPU, 0-based): {self.assign.tolist()}",
            f"  有效内存 c_eff: {np.round(self.c_eff, 3)}",
            f"  有效延迟 d_eff: {np.round(self.d_eff, 3)}",
            f"  i_bar (最少常驻层) = {self.i_bar}  -> 可卸载层 = {self.droppable_layers}",
            f"  B_per_gpu (数学钩子) = {np.round(self.B_per_gpu, 4)}",
        ]
        if self.mem_cap is not None:
            lines.append(f"  显存上限 mem_cap = {self.mem_cap.tolist()}")
        for g in range(self.M):
            lines.append(f"  GPU{g}: 层 {self.layers_on_gpu(g)}")
        return "\n".join(lines)


def homogeneous(c_vec, d_vec, M: int) -> tuple[np.ndarray, np.ndarray]:
    """便捷函数: 由单 GPU 层参数构造同构 M-GPU 的 (M, N) 参数矩阵。"""
    c_vec = np.asarray(c_vec, dtype=float)
    d_vec = np.asarray(d_vec, dtype=float)
    return np.tile(c_vec, (M, 1)), np.tile(d_vec, (M, 1))


if __name__ == "__main__":
    # 快速自检 1: M=1 退化, 应与单 GPU TABLE I 完全一致
    c, d = homogeneous(np.ones(5), np.ones(5), M=1)
    m1 = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0, assign=np.zeros(5, int))
    print(m1.summary())
    for t_bar, tau in [(30, 20), (10, 20), (10, 35), (30, 35)]:
        r = m1.cost([t_bar], tau)
        print(f"  t_bar={t_bar:>2}, tau={tau:>2} -> total={r['total']:.0f}")

    # 快速自检 2: 同构 2-GPU, 层交替分配
    print()
    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    m2 = MultiGPUSystemModel(
        c=c, d=d, eta=30.0, d_qos=2.0,
        assign=np.array([0, 1, 0, 1, 0]), mem_cap=np.array([3.0, 2.0]),
    )
    print(m2.summary())
    r = m2.cost([10.0, 10.0], 35.0)
    print(f"  两 GPU 都在 t=10 卸 -> total={r['total']:.0f}, "
          f"delay={r['loading_delay']:.0f}, per_gpu_mem={r['per_gpu_mem_at_arrival']}")
