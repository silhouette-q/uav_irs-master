"""
env_single_gpu.py
=================
单 GPU 层粒度卸载的【DRL 环境】—— 把论文的系统模型封装成 状态/动作/奖励。

设计目标 (对齐组会要求):
  - 只做【系统建模】: 明确定义状态空间、动作空间、优化目标(=奖励)。
  - 不含求解算法: 环境里没有 LUA / 对偶解 / 训练好的策略; agent 由外部提供。
  - 把 i_bar、B 等【数学钩子】放进 info, 供将来约束 DRL 动作空间使用。

Gym 风格 API (不硬依赖 gymnasium):
  obs = env.reset()
  obs, reward, terminated, truncated, info = env.step(action)

一个 episode = 一个"空闲期":
  t=0 时模型空闲、全部层在显存 (状态 s_N)。
  下一个请求在 τ 时刻到达 (从 ArrivalProcess 采样, 对 agent 隐藏)。
  agent 决定何时卸载"可卸层" (i_bar+1..N)。请求到达即回合结束、结算成本。

回合累计奖励 == -SystemModel.cost(t_bar, τ)  (环境与成本模型自洽, 见 validate)。
"""

from __future__ import annotations

import numpy as np

from arrivals import ArrivalProcess, SlidingWindow
from system_model import SystemModel


# 动作 (离散逐 tick 模式)
ACTION_HOLD = 0     # 保持当前保留状态
ACTION_UNLOAD = 1   # 立刻卸载可卸层 (s_N -> s_{i_bar}); 一旦卸载不可逆


class SingleGPUUnloadEnv:
    """单 GPU 层粒度卸载环境。

    参数
    ----
    model : SystemModel, 系统模型 (层参数 + eta + QoS)。
    arrivals : ArrivalProcess, 请求到达间隔采样器。
    dt : 时间步长 (离散模式下每 step 推进的时间)。
    mode : "step" 逐 tick 在线决策 (默认, DRL 用) | "single" 单发给定 t_bar。
    max_steps : 安全上限, 防止 τ 过大时死循环。
    window_capacity : 到达间隔滑动窗口容量 (用于统计量 q_B+/mu/sigma)。
    """

    def __init__(
        self,
        model: SystemModel,
        arrivals: ArrivalProcess,
        dt: float = 1.0,
        mode: str = "step",
        max_steps: int = 100_000,
        window_capacity: int = 50,
    ) -> None:
        self.model = model
        self.arrivals = arrivals
        self.dt = float(dt)
        self.mode = mode
        self.max_steps = max_steps
        self.window = SlidingWindow(capacity=window_capacity)

        # 观测向量维度 (见 _obs)
        self.obs_dim = 9

        self._reset_episode_state()

    # ---------- 内部状态 ----------
    def _reset_episode_state(self) -> None:
        self.t = 0.0
        self.tau = 0.0
        self.unloaded = False
        self.t_bar = None          # 实际卸载时刻 (未卸载则 None)
        self.mem_cost = 0.0        # 已累计内存成本
        self.steps = 0
        self.done = False

    def _current_state_index(self) -> int:
        return self.model.i_bar if self.unloaded else self.model.N

    def _current_C(self) -> float:
        return self.model.C[self._current_state_index()]

    def _current_D(self) -> float:
        return self.model.D[self._current_state_index()]

    # ---------- 观测 ----------
    def _obs(self) -> np.ndarray:
        s = self.window.stats(self.model.B)
        B = self.model.B if np.isfinite(self.model.B) else -1.0
        return np.array(
            [
                self.t,                      # 已空闲时间
                float(self.unloaded),        # 是否已卸载可卸层
                float(self.model.i_bar),     # QoS 最少常驻层 (数学钩子)
                B,                           # ski-rental 临界点 (数学钩子)
                s["q_B_plus"],               # 长间隔概率
                s["mu_B_minus"],             # 短间隔一阶矩
                s["sigma_B_minus"],          # 短间隔二阶矩
                self._current_C(),           # 当前内存占用
                self._current_D(),           # 当前若被请求的加载延迟
            ],
            dtype=np.float32,
        )

    def _info(self) -> dict:
        return {
            "t": self.t,
            "tau": self.tau,            # 真值 (调试/评估用, agent 训练时不应读)
            "unloaded": self.unloaded,
            "t_bar": self.t_bar,
            "i_bar": self.model.i_bar,
            "B": self.model.B,
            "mem_cost": self.mem_cost,
            "droppable_layers": self.model.droppable_layers,
        }

    # ---------- Gym 风格接口 ----------
    def reset(self) -> np.ndarray:
        # 把上一回合的 τ 记入滑动窗口 (历史到达间隔), 供统计量估计
        if self.tau > 0:
            self.window.push(self.tau)
        self._reset_episode_state()
        self.tau = float(self.arrivals.sample())
        return self._obs()

    def step(self, action):
        if self.mode == "single":
            return self._step_single(action)
        return self._step_tick(action)

    def _step_tick(self, action: int):
        """离散逐 tick 在线决策。action ∈ {HOLD, UNLOAD}。"""
        if self.done:
            raise RuntimeError("episode 已结束, 请先 reset()")

        # 1) 执行动作: 卸载不可逆
        if action == ACTION_UNLOAD and not self.unloaded:
            self.unloaded = True
            self.t_bar = self.t

        # 2) 推进时间, 累计内存成本; 检查请求是否在本 tick 到达
        C_now = self._current_C()
        next_t = self.t + self.dt
        reward = 0.0

        if next_t >= self.tau:
            # 请求在本 tick 内到达
            dt_eff = self.tau - self.t
            self.mem_cost += C_now * dt_eff
            reward -= C_now * dt_eff
            self.t = self.tau
            # 结算加载延迟 (终止惩罚)
            loading_delay = self._current_D()
            reward -= self.model.eta * loading_delay
            self.done = True
            info = self._info()
            info["loading_delay"] = loading_delay
            info["total_cost"] = self.mem_cost + self.model.eta * loading_delay
            info["qos_ok"] = loading_delay <= self.model.d_qos
            return self._obs(), reward, True, False, info

        # 请求未到, 正常推进
        self.mem_cost += C_now * self.dt
        reward -= C_now * self.dt
        self.t = next_t
        self.steps += 1

        truncated = self.steps >= self.max_steps
        if truncated:
            self.done = True
        return self._obs(), reward, False, truncated, self._info()

    def _step_single(self, t_bar: float):
        """单发模式: 一次给定卸载时刻 t_bar, 直接算完整回合成本。"""
        if self.done:
            raise RuntimeError("episode 已结束, 请先 reset()")
        r = self.model.cost(float(t_bar), self.tau)
        self.t_bar = float(t_bar)
        self.unloaded = t_bar < self.tau
        self.t = self.tau
        self.mem_cost = r["memory_cost"]
        self.done = True
        reward = -r["total"]
        info = self._info()
        info.update(r)
        return self._obs(), reward, True, False, info


if __name__ == "__main__":
    # 冒烟测试: 用 TABLE I 模型, 固定阈值策略, 验证回合奖励 == -cost
    from system_model import SystemModel

    m = SystemModel(c=np.ones(5), d=np.ones(5), eta=30.0, d_qos=2.0)
    env = SingleGPUUnloadEnv(m, ArrivalProcess(mode="deterministic", value=20.0), dt=1.0)

    obs = env.reset()
    total_r = 0.0
    # 策略: 空闲到 t>=10 就卸载
    done = False
    while not done:
        a = ACTION_UNLOAD if env.t >= 10 else ACTION_HOLD
        obs, r, done, trunc, info = env.step(a)
        total_r += r
    print("回合累计奖励:", total_r, " -> -cost 应为", -m.cost(10, 20)["total"])
    print("info:", {k: info[k] for k in ("t_bar", "total_cost", "qos_ok")})
