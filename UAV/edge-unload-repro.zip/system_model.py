"""
system_model.py
===============
单 GPU「层粒度卸载」系统模型 —— 忠实复现论文第四节 A/B/C 的建模量。

论文: Efficient Layer-Granularity Unloading for LLMs in Edge Computing (IEEE TMC 2026)

本文件只做【系统建模】, 不含任何求解算法 (LUA / ski-rental 对偶解一律不实现)。
它提供:
  - 层参数 c_i (内存), d_i (加载延迟)
  - 派生建模量: C_i, D_i, i_bar (QoS 最少常驻层), B (ski-rental 临界点, 仅作数学钩子)
  - 成本函数 cost(t_bar, tau): 论文式(2a)的实现

索引约定
--------
- 层编号 1..N (论文 i in I). 代码内部用 0-based 数组存 c[0..N-1], d[0..N-1].
- 状态 s_i (i in 0..N): 第 1..i 层保留, 第 i+1..N 层卸载. s_N = 全保留, s_0 = 全卸载.

关键公式 (论文 A 节)
--------------------
  C_i = sum_{i' <= i} c_{i'}          状态 s_i 的内存占用   (递增)
  D_i = sum_{i' >  i} d_{i'}          从 s_i 重载到满的延迟 (递减)
  ⚠ 这里用 ">i" 而非论文正文的 ">=i". 论文正文的 >=i 是笔误:
     只有 >i 才能复现 TABLE I 的成本 (100/140/185/225), 且与状态定义自洽
     (s_i 已经保留了第 i 层, 服务请求只需重载它之后的层).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass
class SystemModel:
    """单 GPU 层粒度卸载的系统模型 (纯建模, 无求解算法)。

    参数
    ----
    c : 各层内存占用, 长度 N (层 1..N). 单位任意 (GB 或 MB), 只要与 d 的量纲搭配即可。
    d : 各层加载延迟, 长度 N.
    eta : 加载延迟的权重 (论文 eta), 把延迟折算到内存成本量纲。
    d_qos : QoS 约束, 加载延迟上限 D_QoS。
    """

    c: np.ndarray
    d: np.ndarray
    eta: float
    d_qos: float

    # 以下为派生量, 在 __post_init__ 中预计算
    N: int = field(init=False)
    C: np.ndarray = field(init=False)   # C[i], i=0..N
    D: np.ndarray = field(init=False)   # D[i], i=0..N  (用 >i)
    i_bar: int = field(init=False)
    B: float = field(init=False)

    def __post_init__(self) -> None:
        self.c = np.asarray(self.c, dtype=float)
        self.d = np.asarray(self.d, dtype=float)
        if self.c.shape != self.d.shape:
            raise ValueError("c 和 d 长度必须一致 (每层一个内存值和一个延迟值)")
        self.N = int(self.c.shape[0])

        # C[i] = 前 i 层内存之和;  C[0]=0, C[N]=总内存
        self.C = np.concatenate([[0.0], np.cumsum(self.c)])

        # D[i] = 第 i+1..N 层延迟之和 (>i);  D[N]=0, D[0]=总延迟
        total_d = float(self.d.sum())
        # D[i] = total_d - sum_{i' <= i} d_{i'}
        cum_d = np.concatenate([[0.0], np.cumsum(self.d)])  # cum_d[i] = sum_{i'<=i} d
        self.D = total_d - cum_d                            # 长度 N+1, D[i]

        self.i_bar = self._compute_i_bar()
        self.B = self._compute_B()

    # ---------- 派生建模量 ----------
    def _compute_i_bar(self) -> int:
        """i_bar = min{ i | D_i <= D_QoS }  (论文式 1a)。

        第 1..i_bar 层必须常驻内存 (否则加载延迟超 QoS)。
        可卸载层为 i_bar+1 .. N。
        """
        for i in range(self.N + 1):
            if self.D[i] <= self.d_qos:
                return i
        # 理论上 D[N]=0 <= d_qos 必成立, 不会走到这里
        raise ValueError("没有满足 QoS 的状态, 检查 d_qos 是否为负")

    def _compute_B(self) -> float:
        """ski-rental 临界点 B = eta * D_{i_bar} / (C_N - C_{i_bar})。

        注意: 这是【建模量/数学钩子】, 将来用于约束 DRL 动作空间;
        本文件不基于 B 做任何在线求解 (那是 LUA 算法的事, 本周不实现)。
        """
        denom = self.C[self.N] - self.C[self.i_bar]
        if denom <= 0:
            # 没有可卸载层 (i_bar == N), B 无意义
            return math.inf
        return self.eta * self.D[self.i_bar] / denom

    @property
    def droppable_layers(self) -> list[int]:
        """可卸载层的 1-based 编号列表: i_bar+1 .. N。"""
        return list(range(self.i_bar + 1, self.N + 1))

    # ---------- 状态与成本 (论文 C 节 2-斜率形式) ----------
    def state_at(self, t: float, t_bar: float) -> int:
        """在 2-斜率策略下, 时刻 t 的保留状态索引。

        可卸载层在同一时刻 t_bar 一起卸载 (论文 C 节结论):
          t <  t_bar -> 全保留 s_N
          t >= t_bar -> 收缩到 s_{i_bar}
        """
        return self.N if t < t_bar else self.i_bar

    def cost(self, t_bar: float, tau: float) -> dict:
        """论文式(2a)的成本 —— 2-斜率单阈值版。

        给定卸载时刻 t_bar 和下一个请求到达时刻 tau, 返回成本明细。
          memory_cost = ∫_0^tau C(state at t) dt
          loading_delay = D(state at tau)
          total = eta * loading_delay + memory_cost
        """
        if t_bar >= tau:
            # 请求先到, 还没来得及卸载 -> 全程全保留
            memory_cost = self.C[self.N] * tau
            state_tau = self.N
        else:
            memory_cost = self.C[self.N] * t_bar + self.C[self.i_bar] * (tau - t_bar)
            state_tau = self.i_bar

        loading_delay = self.D[state_tau]
        total = self.eta * loading_delay + memory_cost
        return {
            "total": total,
            "memory_cost": memory_cost,
            "loading_delay": loading_delay,
            "state_at_arrival": state_tau,
            "qos_ok": loading_delay <= self.d_qos,
        }

    # ---------- 一般版 (逐层调度, 为多 GPU / 非嵌套扩展预留) ----------
    def cost_schedule(self, t_list, tau: float) -> dict:
        """一般版成本: 每层一个卸载时刻 t_list[j] (层 j+1), 不要求嵌套。

        memory_cost  = sum_j c_j * min(t_j, tau)          每层被保留的时长 * 内存
        loading_delay= sum_j d_j * [t_j <= tau]           已卸载且需重载的层
        total        = eta * loading_delay + memory_cost

        当 t_list = [inf]*i_bar + [t_bar]*(可卸层数) 时, 与 cost(t_bar, tau) 等价。
        """
        t_arr = np.asarray(t_list, dtype=float)
        if t_arr.shape[0] != self.N:
            raise ValueError("t_list 长度必须等于层数 N")

        retained_dur = np.minimum(t_arr, tau)          # 每层被保留的时长
        memory_cost = float((self.c * retained_dur).sum())

        unloaded = t_arr <= tau                        # 到 tau 时已卸载的层
        loading_delay = float((self.d * unloaded).sum())

        total = self.eta * loading_delay + memory_cost
        return {
            "total": total,
            "memory_cost": memory_cost,
            "loading_delay": loading_delay,
            "qos_ok": loading_delay <= self.d_qos,
        }

    # ---------- 便捷打印 ----------
    def summary(self) -> str:
        return (
            f"SystemModel(N={self.N}, eta={self.eta}, D_QoS={self.d_qos})\n"
            f"  C (内存, 递增): {np.round(self.C, 3)}\n"
            f"  D (延迟, 递减): {np.round(self.D, 3)}\n"
            f"  i_bar (最少常驻层) = {self.i_bar}  -> 可卸载层 = {self.droppable_layers}\n"
            f"  B (ski-rental 临界点, 数学钩子) = {self.B:.4f}"
        )


if __name__ == "__main__":
    # 快速自检: TABLE I 动机例子 (5 层, 1GB/1s, eta=30, QoS<=2s)
    m = SystemModel(c=np.ones(5), d=np.ones(5), eta=30.0, d_qos=2.0)
    print(m.summary())
    for t_bar, tau in [(30, 20), (10, 20), (10, 35), (30, 35)]:
        r = m.cost(t_bar, tau)
        print(f"  t_bar={t_bar:>2}, tau={tau:>2} -> total={r['total']:.0f} "
              f"(mem={r['memory_cost']:.0f}, delay={r['loading_delay']:.0f})")
