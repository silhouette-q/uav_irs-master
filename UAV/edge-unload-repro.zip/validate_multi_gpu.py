"""
validate_multi_gpu.py
=====================
多 GPU 系统模型正确性验证 (可整体跑, 也可按名字单跑某项)。

用法:
  python validate_multi_gpu.py                 # 跑全部 7 项
  python validate_multi_gpu.py --list          # 列出所有子测试
  python validate_multi_gpu.py degenerate env  # 只跑指定子测试

核心思路: 单 GPU 的 TABLE I 已经手算+代码双重核对过, 是我们的 ground-truth。
多 GPU 模型必须满足一组"退化/一致性"性质:

  degenerate : M=1 退化, 与单 GPU SystemModel 在 TABLE I 上完全一致。
  homo_equiv : 同构 M-GPU + delay_agg="sum" + 同时刻卸 == 单 GPU 成本。
  delay_agg  : 并行重载 (max) 延迟 <= 串行 (sum); 并行会放宽 QoS。
  hetero     : 同一层在不同 GPU 上参数不同时, c_eff/d_eff 随 assign 变化。
  mem_cap    : 常驻层放不下的分配直接报错; 运行时越界能被检出。
  migration  : kappa>0 且分配偏离参考分配时计入 kappa*c。
  env        : 环境回合累计奖励 == -cost(t_bar_per_gpu, tau)。
"""

from __future__ import annotations

import argparse
import sys

import numpy as np

# Windows 控制台默认 GBK, 强制 UTF-8 输出避免中文乱码/emoji 报错
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from arrivals import ArrivalProcess
from env_multi_gpu import MultiGPUUnloadEnv
from system_model import SystemModel
from system_model_multi_gpu import MultiGPUSystemModel, homogeneous

TABLE1_CASES = [(30.0, 20.0), (10.0, 20.0), (10.0, 35.0), (30.0, 35.0)]
TABLE1_COSTS = [100.0, 140.0, 185.0, 225.0]


def build_single() -> SystemModel:
    return SystemModel(c=np.ones(5), d=np.ones(5), eta=30.0, d_qos=2.0)


# ---------- 子测试 (每项独立可跑) ----------

def test_degenerate() -> None:
    """M=1 退化: 与单 GPU 完全一致。"""
    single = build_single()
    c, d = homogeneous(np.ones(5), np.ones(5), M=1)
    m1 = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0, assign=np.zeros(5, int))
    assert m1.i_bar == single.i_bar == 3
    assert m1.droppable_layers == single.droppable_layers == [4, 5]
    assert abs(m1.B_per_gpu[0] - single.B) < 1e-9
    for (t_bar, tau), exp in zip(TABLE1_CASES, TABLE1_COSTS):
        got = m1.cost([t_bar], tau)["total"]
        ref = single.cost(t_bar, tau)["total"]
        assert abs(got - exp) < 1e-9 and abs(got - ref) < 1e-9, (
            f"M=1 退化失败: cost({t_bar},{tau}) = {got}, 预期 {exp}"
        )
    print("[OK] M=1 退化: i_bar/B/TABLE I 四成本与单 GPU 完全一致")


def test_homo_equiv() -> None:
    """同构等价: 同构 M-GPU + sum + 同时刻卸 == 单 GPU。"""
    for M, assign in [(2, [0, 1, 0, 1, 0]), (3, [0, 1, 2, 1, 0])]:
        c, d = homogeneous(np.ones(5), np.ones(5), M=M)
        mm = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                                 assign=np.array(assign), delay_agg="sum")
        assert mm.i_bar == 3, f"同构 M={M} 的 i_bar 应仍为 3"
        for (t_bar, tau), exp in zip(TABLE1_CASES, TABLE1_COSTS):
            got = mm.cost([t_bar] * M, tau)["total"]
            assert abs(got - exp) < 1e-9, (
                f"同构 M={M} 等价失败: cost = {got}, 预期 {exp}"
            )
    print("[OK] 同构等价: M=2/3 + delay_agg=sum + 同时刻卸 == 单 GPU 成本")


def test_delay_agg() -> None:
    """并行重载 (max) <= 串行 (sum); 并行放宽 QoS。"""
    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    kw = dict(c=c, d=d, eta=30.0, d_qos=2.0, assign=np.array([0, 1, 0, 1, 0]))
    m_sum = MultiGPUSystemModel(delay_agg="sum", **kw)
    m_max = MultiGPUSystemModel(delay_agg="max", **kw)
    # 并行重载让 QoS 更容易满足 -> i_bar 更小:
    # 卸层 2..5 时 GPU0 重载 {3,5}=2s, GPU1 重载 {2,4}=2s, max=2 <= QoS -> i_bar=1
    assert m_sum.i_bar == 3 and m_max.i_bar == 1, (
        f"i_bar: sum={m_sum.i_bar} (应3), max={m_max.i_bar} (应1)"
    )
    # 同一卸载调度下逐点比较: max 延迟 <= sum 延迟, 总成本同向
    for t_bar, tau in TABLE1_CASES:
        t_list = [np.inf] * 3 + [t_bar] * 2
        a = m_max.cost_schedule(t_list, tau)
        b = m_sum.cost_schedule(t_list, tau)
        assert a["loading_delay"] <= b["loading_delay"] + 1e-9
        assert a["total"] <= b["total"] + 1e-9
    # 卸层 {4,5} 分在两个 GPU 上各 1s -> max 应为 1 (并行), sum 为 2 (串行)
    t_list = [np.inf] * 3 + [10.0, 10.0]
    assert abs(m_max.cost_schedule(t_list, 35.0)["loading_delay"] - 1.0) < 1e-9
    assert abs(m_sum.cost_schedule(t_list, 35.0)["loading_delay"] - 2.0) < 1e-9
    print("[OK] 重载聚合: max(并行)=1s <= sum(串行)=2s; 且并行放宽 QoS (i_bar 3->1)")


def test_hetero() -> None:
    """异构: 同一层在不同 GPU 上参数不同。"""
    c_het = np.array([[1.0] * 5, [2.0] * 5])   # GPU1 上每层内存翻倍
    d_het = np.array([[1.0] * 5, [0.5] * 5])   # GPU1 上加载快一倍
    mh0 = MultiGPUSystemModel(c=c_het, d=d_het, eta=30.0, d_qos=2.0,
                              assign=np.zeros(5, int))          # 全在 GPU0
    mh1 = MultiGPUSystemModel(c=c_het, d=d_het, eta=30.0, d_qos=2.0,
                              assign=np.ones(5, int))           # 全在 GPU1
    assert np.allclose(mh0.c_eff, 1.0) and np.allclose(mh1.c_eff, 2.0)
    assert np.allclose(mh0.d_eff, 1.0) and np.allclose(mh1.d_eff, 0.5)
    # GPU1 加载快 -> QoS 更松 -> 常驻层更少 (i_bar 更小)
    assert mh1.i_bar < mh0.i_bar, f"异构 i_bar: GPU1({mh1.i_bar}) 应 < GPU0({mh0.i_bar})"
    print(f"[OK] 异构生效: 全放 GPU0 -> i_bar={mh0.i_bar}; "
          f"全放 GPU1(加载快) -> i_bar={mh1.i_bar}")


def test_mem_cap() -> None:
    """显存约束: 常驻层放不下时报错; check_mem_cap 工作正常。"""
    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    # 常驻层 1..3 全分到 GPU0, 但 GPU0 只有 2GB -> 建模层面直接报错
    try:
        MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                            assign=np.array([0, 0, 0, 1, 1]),
                            mem_cap=np.array([2.0, 5.0]))
        raise AssertionError("常驻层超显存应报错, 但没有")
    except ValueError:
        pass
    # 合法分配 + 运行时检查
    mc = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                             assign=np.array([0, 0, 1, 1, 1]),
                             mem_cap=np.array([2.0, 3.0]))
    assert mc.check_mem_cap(np.ones(5, dtype=bool))   # 全保留恰好占满
    print("[OK] 显存约束: 常驻层放不下时报错; check_mem_cap 工作正常")


def test_migration() -> None:
    """迁移开销: kappa*Σc(被移动层) 计入总成本。"""
    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    mk = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                             assign=np.array([0, 1, 0, 1, 0]), kappa=5.0)
    t_list = [np.inf] * 3 + [10.0, 10.0]
    base = mk.cost_schedule(t_list, 35.0)["total"]
    # 参考分配 = 全在 GPU0, 层 2/4 被移动 -> 迁移成本 5 * (1+1) = 10
    moved = mk.cost_schedule(t_list, 35.0, ref_assign=np.zeros(5, int))
    assert abs(moved["migration_cost"] - 10.0) < 1e-9
    assert abs(moved["total"] - (base + 10.0)) < 1e-9
    print("[OK] 迁移开销: kappa*Σc(被移动层) 正确计入总成本")


def test_env() -> None:
    """环境自洽: 回合累计奖励 == -cost。"""
    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    m2 = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                             assign=np.array([0, 1, 0, 1, 0]))
    for t_bars, tau in [((10.0, 20.0), 35.0), ((10.0, 10.0), 35.0),
                        ((30.0, 30.0), 20.0), ((0.0, 15.0), 20.0)]:
        env = MultiGPUUnloadEnv(
            m2, ArrivalProcess(mode="deterministic", value=tau), dt=1.0
        )
        env.reset()
        total_r, done = 0.0, False
        while not done:
            a = np.array([env.t >= t_bars[0], env.t >= t_bars[1]])
            _, r, done, trunc, info = env.step(a)
            total_r += r
            if trunc:
                break
        cost = m2.cost(list(t_bars), tau)["total"]
        assert abs(total_r - (-cost)) < 1e-6, (
            f"环境奖励({total_r}) != -cost({-cost})  t_bars={t_bars}, tau={tau}"
        )
    print("[OK] 多 GPU 环境回合累计奖励 == -cost (环境与成本模型自洽)")


# 子测试注册表 (按依赖从基础到上层排序)
TESTS = {
    "degenerate": test_degenerate,
    "homo_equiv": test_homo_equiv,
    "delay_agg": test_delay_agg,
    "hetero": test_hetero,
    "mem_cap": test_mem_cap,
    "migration": test_migration,
    "env": test_env,
}


def main(selected: list[str] | None = None) -> bool:
    """跑指定子测试 (None = 全部)。返回是否全部通过。"""
    names = selected or list(TESTS)
    failed = []
    for name in names:
        if name not in TESTS:
            print(f"[SKIP] 未知子测试: {name} (可选: {', '.join(TESTS)})")
            continue
        try:
            TESTS[name]()
        except AssertionError as e:
            failed.append(name)
            print(f"[FAIL] {name}: {e}")
    if failed:
        print(f"\n{len(failed)} 项失败: {', '.join(failed)} [FAIL]")
        return False
    print("\n全部验证通过 [PASS]")
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="多 GPU 系统模型验证")
    parser.add_argument("tests", nargs="*",
                        help=f"要跑的子测试名 (缺省=全部): {', '.join(TESTS)}")
    parser.add_argument("--list", action="store_true", help="列出所有子测试")
    args = parser.parse_args()

    if args.list:
        for name, fn in TESTS.items():
            print(f"  {name:<12} {fn.__doc__.strip().splitlines()[0]}")
        sys.exit(0)

    sys.exit(0 if main(args.tests or None) else 1)
