"""
env_multi_gpu.py
================
多 GPU 层粒度卸载的【DRL 环境】—— 把 MultiGPUSystemModel 封装成 状态/动作/奖励。

设计目标 (对齐组会要求):
  - 只做【系统建模】: 定义状态空间、动作空间、优化目标(=奖励)。
  - 不含求解算法: 环境里没有 LUA / 对偶解 / 训练好的策略; agent 由外部提供。
  - 把 i_bar、B_per_gpu 等【数学钩子】放进 info, 供将来约束 DRL 动作空间。

Gym 风格 API (与 env_single_gpu 相同, 不硬依赖 gymnasium):
  obs = env.reset()
  obs, reward, terminated, truncated, info = env.step(action)

一个 episode = 一个"空闲期":
  t=0 时模型空闲、全部层在各自 GPU 显存中。
  下一个请求在 τ 时刻到达 (采样, 对 agent 隐藏)。
  agent 决定每个 GPU 何时卸载"自己上面的可卸层"。请求到达即结束结算。

相对单 GPU 的扩展:
  - 动作从 {HOLD, UNLOAD} 变为 M 位掩码: action[g]=1 表示 GPU g 立刻卸载
    其上的可卸层 (每个 GPU 独立、不可逆)。也接受整数 0..2^M-1 (二进制掩码)。
  - 观测扩展为 逐 GPU 的 [是否已卸, B_g, 当前显存, 显存上限] 块。
  - 回合累计奖励 == -MultiGPUSystemModel.cost(t_bar_per_gpu, τ)  (见 validate)。

层->GPU 的分配 assign 是另一个决策变量, 但它在一个空闲期内固定,
由构造模型时给定 —— 本环境只暴露"何时卸"这一在线决策 (与论文问题对齐);
"分给谁"属于放置问题, 将来可作为上层(episode 级)动作再扩展。
"""

from __future__ import annotations

import numpy as np

from arrivals import ArrivalProcess, SlidingWindow
from system_model_multi_gpu import MultiGPUSystemModel


class MultiGPUUnloadEnv:
    """多 GPU 层粒度卸载环境。

    参数
    ----
    model : MultiGPUSystemModel, 多 GPU 系统模型。
    arrivals : ArrivalProcess, 请求到达间隔采样器。
    dt : 时间步长。
    max_steps : 安全上限, 防止 τ 过大时死循环。
    window_capacity : 到达间隔滑动窗口容量 (统计量 q_B+/mu/sigma 用)。
    """

    def __init__(
        self,
        model: MultiGPUSystemModel,
        arrivals: ArrivalProcess,
        dt: float = 1.0,
        max_steps: int = 100_000,
        window_capacity: int = 50,
    ) -> None:
        self.model = model
        self.arrivals = arrivals
        self.dt = float(dt)
        self.max_steps = max_steps
        self.window = SlidingWindow(capacity=window_capacity)

        # 观测 = 全局 6 维 + 每 GPU 4 维 (见 _obs)
        self.obs_dim = 6 + 4 * self.model.M
        # 动作空间: M 位掩码 (向量) 或整数 0..2^M-1
        self.action_dim = self.model.M

        self._reset_episode_state()

    # ---------- 内部状态 ----------
    def _reset_episode_state(self) -> None:
        m = self.model
        self.t = 0.0
        self.tau = 0.0
        self.unloaded = np.zeros(m.M, dtype=bool)   # 每 GPU 是否已卸其可卸层
        self.t_bar = np.full(m.M, np.inf)           # 每 GPU 实际卸载时刻
        self.mem_cost = 0.0
        self.steps = 0
        self.done = False

    def _retained_mask(self) -> np.ndarray:
        """当前保留层掩码 (长度 N): 常驻层永远保留; 可卸层看其 GPU 是否已卸。"""
        m = self.model
        mask = np.ones(m.N, dtype=bool)
        for i in range(m.i_bar, m.N):
            mask[i] = not self.unloaded[m.assign[i]]
        return mask

    def _current_C_total(self) -> float:
        """当前跨 GPU 总内存占用 (成本斜率)。"""
        return float(self.model.gpu_memory_usage(self._retained_mask()).sum())

    def _current_D(self) -> float:
        """当前若被请求, 需要的重载延迟 (按 delay_agg 聚合)。"""
        return self.model._reload_delay(~self._retained_mask())

    # ---------- 观测 ----------
    def _obs(self) -> np.ndarray:
        m = self.model
        B_min = float(np.min(m.B_per_gpu))
        s = self.window.stats(B_min if np.isfinite(B_min) else 0.0)

        glob = [
            self.t,                       # 已空闲时间
            float(m.i_bar),               # QoS 最少常驻层 (数学钩子)
            s["q_B_plus"],                # 长间隔概率
            s["mu_B_minus"],              # 短间隔一阶矩
            s["sigma_B_minus"],           # 短间隔二阶矩
            self._current_D(),            # 当前若被请求的加载延迟
        ]
        usage = m.gpu_memory_usage(self._retained_mask())
        cap = m.mem_cap if m.mem_cap is not None else np.full(m.M, -1.0)
        per_gpu = []
        for g in range(m.M):
            B_g = m.B_per_gpu[g] if np.isfinite(m.B_per_gpu[g]) else -1.0
            per_gpu += [float(self.unloaded[g]), B_g, float(usage[g]), float(cap[g])]
        return np.array(glob + per_gpu, dtype=np.float32)

    def _info(self) -> dict:
        m = self.model
        return {
            "t": self.t,
            "tau": self.tau,             # 真值 (调试/评估用, agent 训练时不应读)
            "unloaded": self.unloaded.copy(),
            "t_bar": self.t_bar.copy(),
            "i_bar": m.i_bar,
            "B_per_gpu": m.B_per_gpu.copy(),
            "mem_cost": self.mem_cost,
            "droppable_layers": m.droppable_layers,
            "per_gpu_mem": m.gpu_memory_usage(self._retained_mask()).tolist(),
            "mem_cap_ok": m.check_mem_cap(self._retained_mask()),
        }

    # ---------- Gym 风格接口 ----------
    def reset(self) -> np.ndarray:
        if self.tau > 0:
            self.window.push(self.tau)
        self._reset_episode_state()
        self.tau = float(self.arrivals.sample())
        return self._obs()

    def _parse_action(self, action) -> np.ndarray:
        """动作 -> M 位卸载掩码。接受向量 (0/1) 或整数 (二进制掩码)。"""
        M = self.model.M
        if np.isscalar(action):
            a = int(action)
            if not 0 <= a < 2 ** M:
                raise ValueError(f"整数动作必须在 0..{2**M - 1}")
            return np.array([(a >> g) & 1 for g in range(M)], dtype=bool)
        arr = np.asarray(action).astype(bool)
        if arr.shape[0] != M:
            raise ValueError(f"动作向量长度必须为 M={M}")
        return arr

    def step(self, action):
        """逐 tick 在线决策。action = M 位掩码 (哪些 GPU 现在卸)。"""
        if self.done:
            raise RuntimeError("episode 已结束, 请先 reset()")

        # 1) 执行动作: 各 GPU 独立卸载, 不可逆
        fire = self._parse_action(action) & ~self.unloaded
        self.unloaded |= fire
        self.t_bar[fire] = self.t

        # 2) 推进时间, 累计内存成本; 检查请求是否在本 tick 到达
        C_now = self._current_C_total()
        next_t = self.t + self.dt
        reward = 0.0

        if next_t >= self.tau:
            # 请求在本 tick 内到达
            dt_eff = self.tau - self.t
            self.mem_cost += C_now * dt_eff
            reward -= C_now * dt_eff
            self.t = self.tau
            loading_delay = self._current_D()
            reward -= self.model.eta * loading_delay
            self.done = True
            info = self._info()
            info["loading_delay"] = loading_delay
            info["total_cost"] = self.mem_cost + self.model.eta * loading_delay
            info["qos_ok"] = loading_delay <= self.model.d_qos
            return self._obs(), reward, True, False, info

        # 请求未到, 正常推进
        self.mem_cost += C_now * self.dt
        reward -= C_now * self.dt
        self.t = next_t
        self.steps += 1

        truncated = self.steps >= self.max_steps
        if truncated:
            self.done = True
        return self._obs(), reward, False, truncated, self._info()


if __name__ == "__main__":
    # 冒烟测试: 同构 2-GPU, 两 GPU 分别在 t=10 / t=20 卸, 验证奖励 == -cost
    from system_model_multi_gpu import homogeneous

    c, d = homogeneous(np.ones(5), np.ones(5), M=2)
    m = MultiGPUSystemModel(c=c, d=d, eta=30.0, d_qos=2.0,
                            assign=np.array([0, 1, 0, 1, 0]))
    env = MultiGPUUnloadEnv(m, ArrivalProcess(mode="deterministic", value=35.0), dt=1.0)

    env.reset()
    total_r, done = 0.0, False
    while not done:
        a = np.array([env.t >= 10, env.t >= 20])
        _, r, done, trunc, info = env.step(a)
        total_r += r
    expect = -m.cost([10.0, 20.0], 35.0)["total"]
    print("回合累计奖励:", total_r, " -> -cost 应为", expect)
    print("info:", {k: info[k] for k in ("t_bar", "total_cost", "qos_ok")})
