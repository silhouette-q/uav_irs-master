"""
run_tests.py
============
统一测试入口: 单 GPU / 多 GPU 可分开跑, 也可一起跑。

用法:
  python run_tests.py            # 全跑 (单 GPU + 多 GPU)
  python run_tests.py --single   # 只跑单 GPU (TABLE I)
  python run_tests.py --multi    # 只跑多 GPU
  python run_tests.py --multi degenerate env   # 只跑多 GPU 的指定子项
"""

from __future__ import annotations

import argparse
import sys

# Windows 控制台默认 GBK, 强制 UTF-8 输出避免中文乱码/emoji 报错
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import validate_multi_gpu
import validate_table1


def run_single() -> bool:
    print("=" * 60)
    print("单 GPU 验证 (validate_table1)")
    print("=" * 60)
    try:
        validate_table1.main()
        return True
    except AssertionError as e:
        print(f"[FAIL] {e}")
        return False


def run_multi(tests: list[str] | None = None) -> bool:
    print("=" * 60)
    print("多 GPU 验证 (validate_multi_gpu)")
    print("=" * 60)
    return validate_multi_gpu.main(tests)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="单/多 GPU 系统模型统一测试入口")
    parser.add_argument("--single", action="store_true", help="只跑单 GPU 验证")
    parser.add_argument("--multi", action="store_true", help="只跑多 GPU 验证")
    parser.add_argument("tests", nargs="*",
                        help="多 GPU 子测试名 (配合 --multi, 缺省=全部)")
    args = parser.parse_args()

    run_s = args.single or not (args.single or args.multi)
    run_m = args.multi or not (args.single or args.multi)

    ok = True
    if run_s:
        ok = run_single() and ok
        print()
    if run_m:
        ok = run_multi(args.tests or None) and ok

    print()
    print("总结果:", "全部通过 [PASS]" if ok else "存在失败 [FAIL]")
    sys.exit(0 if ok else 1)
